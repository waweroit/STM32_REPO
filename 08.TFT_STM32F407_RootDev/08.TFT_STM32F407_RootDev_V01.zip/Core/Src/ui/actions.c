/*
 * actions.c
 *
 *  Created on: Jan 19, 2025
 *      Author: wawer
 */
#include "ui.h"
#include "actions.h"
#include "screens.h"
#include "vars.h"
#include "ili9341.h"
#include "File_Handling.h"
#include <stdbool.h>

void action_car_start_stop_engine_button_pressed(lv_event_t * e)
{

}

void action_lo_ra_reset_button_pressed(lv_event_t * e)
{

}

void action_wi_fi_reset_button_pressed(lv_event_t * e)
{

}

void action_wi_fi_disable_button_pressed(lv_event_t * e)
{

}

void action_car_auto_start_switch_pressed(lv_event_t * e)
{

}
