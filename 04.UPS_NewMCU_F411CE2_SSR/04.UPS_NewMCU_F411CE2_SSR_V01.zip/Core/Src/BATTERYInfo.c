/*
 * BATTERYInfo.c
 *
 *  Created on: Aug 26, 2024
 *      Author: wawer
 */
#include "BATTERYInfo.h"

volatile bool WasChargedEnough = true;

float ReadDCBattVoltageFromADC(uint32_t *Buffer, int size)// VoltageOfSensor can be 3.3 or 5
{
	uint32_t readValue=0;
	float voltage =0;

    for (int i = 0; i < size; i++)
    {
    	readValue += Buffer[i];
    }
    readValue = readValue / size;

	//voltage =(float)readValue/4095*(37.5/7.5*VoltageOfSensor); 37,5 oraz 7.5 to rezystory na płytce PCB
	//voltage =(float)readValue/4095*5*VoltageOfPowerSensor;
	//voltage =(float)readValue/4095*(37.5/7.5*VoltageOfSensor); 37,5 oraz 7.5 to rezystory na płytce PCB
	    voltage =(float)readValue/4095*16.5; //(dla 3.3 volta)
//	    voltage =(float)readValue/4095*25; //(dla 5.0 volta)
	if(voltage <= 0.9)
	    	voltage = 0;
	return voltage;

}


eBatteryStatus BatteryInformation(float batteryDischarged, float batteryVoltage)
{
	//float batteryDischarged = 11.2;
	eBatteryStatus batStatus = NO_BATTERY;

	if(batteryVoltage <= batteryDischarged)
		batStatus = DISCHARGED_BATTERY;
	else if(batteryVoltage > batteryDischarged && batteryVoltage <= 11.2)
		batStatus = OK_BATTERY_LOW;
	else if(batteryVoltage > 11.2 && batteryVoltage <= 12.5)
		batStatus = OK_BATTERY_MID;
	else if(batteryVoltage > 12.5 && batteryVoltage <= 12.8)
		batStatus = OK_BATTERY_HIGH;
	else if(batteryVoltage >= 14.3)
		batStatus = FULL_BATTERY;

	return batStatus;
}
